import 'package:flutter/material.dart';

void main() {
  runApp(const NaijaHomesApp());
}

class NaijaHomesApp extends StatelessWidget {
  const NaijaHomesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NaijaHomes',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("NaijaHomes")),
      body: const Center(
        child: Text("Welcome to NaijaHomes 🚀"),
      ),
    );
  }
}
